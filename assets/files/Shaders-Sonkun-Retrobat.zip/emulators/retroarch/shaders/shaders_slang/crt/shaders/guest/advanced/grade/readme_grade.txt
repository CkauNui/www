Replace the "pre-shaders-afterglow.slang" pass with "pre-shaders-afterglow-grade.slang" or older version

for advanced color grading options.

It's best done through the RA shader menu, where you "click" on the shader pass you want to replace

and then browse / select the version with grade.

Don't forget to push "Apply Changes" after that.